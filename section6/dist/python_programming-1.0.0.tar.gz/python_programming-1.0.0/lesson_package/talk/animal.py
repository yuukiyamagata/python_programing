from lesson_package.tools import utils

def sing():
    return '#FEabrh4w3gh23bea'

def cry():
    return utils.say_twice('fwagwqnh3qwr3##WGEr')