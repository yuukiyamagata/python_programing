from distutils.core import setup


setup(
  name='python_programming',
  version='1.0.0',
  packages=['lesson_package', 'lesson_package.talk', 'lesson_package.tools'],
  utl='https://gojyo.appspopt.com',
  license='Free',
  author='s_getou',
  author_email='test@gmail.com',
  description='Sample package'
)